# Interpolate local ancestry using RFMix v1  

Author: Nicole Gay (nicolerg@stanford.edu)  

## Decscription   
These scripts were written specifically for the purpose of inferring local ancestry in GTEx v8 individuals using 1000 Genomes reference panels for Asian, West African, and European populations. They need to be modified for any other purposes. Please submit an issue in this repository for any questions or concerns. 

## Resources:  
- [RFMix v1.5.4](https://sites.google.com/site/rfmixlocalancestryinference/https://sites.google.com/site/rfmixlocalancestryinference/) 
- [Additional/alternative scripts to run RFMix and format outputs](https://github.com/armartin/ancestry_pipeline)  
- hg19 genetic map: ftp://ftp.ncbi.nlm.nih.gov/hapmap/recombination/2011-01_phaseII_B37/

## Workflow:

1. Download RFMix v1.5.4 and save it in your Home path (see `Resources`)
2. Identify VCFs for admixed individuals (e.g. GTEx) and reference populations (e.g. 1000 Genomes) 
3. Convert all VCFs to hg19. This is required in order to use the hg19 genetic map, which is required to generate inputs for RFMix v1.5.4 (`liftOver-hg38Tohg19.sh` may be helpful)
4. Split VCFs by chromosome to facilitate processing in parallel (`split-vcf-by-chrom.sh` may be helpful)
5. Download the hg19 genetic map if you don't already have one (see `Resources`)
6. Adjust `format-rfmix.sh` as necessary and run the script to do the following:
  - Format inputs for RFMix (`format-rfmix.R`, which needs to be customized for your specific purpose)
  - Run RFMix (v1.5.4)
  - Generate per-individual BED files of contiguous ancestry assignments (`collapse_ancestry_single_chr.py`)
  - Collapse all per-individual BED files into a master BED file (one per chromosome)
  - Use the master BED file to interpolate local ancestry for every variant specified in the VCF file for your admixed individuals (per chromosome). This file is used to construct the local ancestry variables in eQTL calling (`interpolate-local-anc.py`)
